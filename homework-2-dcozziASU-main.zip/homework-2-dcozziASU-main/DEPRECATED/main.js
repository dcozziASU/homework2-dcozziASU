// Hint: declare global variables here
let countrySelector = document.getElementById('countrySelector');

var svg;
let margin = {top: 50, right: 50, bottom: 50, left: 50};
let width = 1000 - margin.left - margin.right;
let height = 600 - margin.top - margin.bottom;

//Instantiate Axes
let x;
let y;

//Instantiate Default Data
let female_data;
let male_data;

//Instantiate Country-Defined Data
let us_data = Array.from(Array(2), () => new Array(33));
let china_data = Array.from(Array(2), () => new Array(33));
let germany_data = Array.from(Array(2), () => new Array(33));
let russia_data = Array.from(Array(2), () => new Array(33));
let uae_data = Array.from(Array(2), () => new Array(33));

// This function is called once the HTML page is fully loaded by the browser
document.addEventListener('DOMContentLoaded', function () {
   // Hint: create or set your svg element inside this function

    svg = d3.select("#my_dataviz")
        .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
        .append("g")
            .attr("transform","translate(" + margin.left + "," + margin.top + ")");
    x = d3.scaleTime()
        .domain([ 1990, 2023 ])
        .range([ 0, width]);

    svg.append("g").attr("transform", "translate(0," + height + ")").call(d3.axisBottom(x).tickFormat(d3.format("d")));
    
    y = d3.scaleLinear()
        .domain([0, 100])
        .range([ height, 0]);
    
    svg.append("g").call(d3.axisLeft(y))

    // This will load your two CSV files and store them into two arrays.
    Promise.all([d3.csv('data/females_data.csv'),d3.csv('data/males_data.csv')])
        .then(function (values) {
            female_data = values[0];
            male_data = values[1];

            //Parse Female Data
            for(let i = 0; i < female_data.length; i++){
                us_data[0][i] = female_data[i]["United States"] * 100;  
                china_data[0][i] = female_data[i]["China"] * 100;
                germany_data[0][i] = female_data[i]["Germany"] * 100;
                russia_data[0][i] = female_data[i]["Russia"] * 100;
                uae_data[0][i] = female_data[i]["United Arab Emirates"] * 100;
            } 
            //Parse Male Data
            for(let i = 0; i < male_data.length; i++){
                us_data[1][i] = male_data[i]["United States"] * 100;  
                china_data[1][i] = male_data[i]["China"] * 100;
                germany_data[1][i] = male_data[i]["Germany"] * 100;
                russia_data[1][i] = male_data[i]["Russia"] * 100;
                uae_data[1][i] = male_data[i]["United Arab Emirates"] * 100;
            }
            
            //Initialize Default
            drawLolliPopChart('United States');
        });
    
});


//Listen For Changes
if(countrySelector){
    countrySelector.addEventListener('change', (event) => {
        drawLolliPopChart(countrySelector.value);
    });
} else {
    console.error("Failed to attach to Country Selector");
}

// Use this function to draw the lollipop chart.
function drawLolliPopChart(selectedCountry) {
    if(selectedCountry == "United States" || selectedCountry == "China" || selectedCountry == "Germany" || selectedCountry == "Russia" || selectedCountry == "United Arab Emirates"){
        switch(selectedCountry){
            case "United States":
                svg.selectAll("myline")
                .data(female_data)
                .enter()
                .append("line")
                    .attr("x", (s) => x(female_data.Country))
                    .attr("y", (s) => y(female_data.value))
                    .attr("stroke", "red")
                break;
            case "China":

                break;
            case "Germany":

                break;
            case "Russia":

                break;
            case "United Arab Emirates":

                break;
        }
    } else {
        console.error("Invalid Country Selection");
    }
}