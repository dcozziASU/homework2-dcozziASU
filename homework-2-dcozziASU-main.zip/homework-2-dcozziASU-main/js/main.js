// Hint: declare global variables here
let countrySelector = document.getElementById('countrySelector');

var svg;
let margin = {top: 50, right: 50, bottom: 50, left: 50};
let width = 1000 - margin.left - margin.right;
let height = 600 - margin.top - margin.bottom;

//Instantiate Axes
let x;
let y;

//Instantiate Default Data
let female_data;
let male_data;

//Instantiate Country-Defined Data
let us_data = Array.from(Array(2), () => new Array(33));
let china_data = Array.from(Array(2), () => new Array(33));
let germany_data = Array.from(Array(2), () => new Array(33));
let russia_data = Array.from(Array(2), () => new Array(33));
let uae_data = Array.from(Array(2), () => new Array(33));

// This function is called once the HTML page is fully loaded by the browser
document.addEventListener('DOMContentLoaded', function () {
   // Hint: create or set your svg element inside this function

    svg = d3.select("#my_dataviz")
        .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
        .append("g")
            .attr("transform","translate(" + margin.left + "," + margin.top + ")");

    // This will load your two CSV files and store them into two arrays.
    Promise.all([d3.csv('data/females_data.csv'),d3.csv('data/males_data.csv')])
        .then(function (values) {
            female_data = values[0];
            male_data = values[1];

            for(let i = 0; i < male_data.length; i++){
                us_data[i] = {"Year": new Date(male_data[i].Year).getFullYear(), "Female": female_data[i]["United States"], "Male": male_data[i]["United States"]};
                china_data[i] = {"Year": new Date(male_data[i].Year).getFullYear(), "Female": female_data[i]["China"], "Male": male_data[i]["China"]};
                germany_data[i] = {"Year": new Date(male_data[i].Year).getFullYear(), "Female": female_data[i]["Germany"], "Male": male_data[i]["Germany"]};
                russia_data[i] = {"Year": new Date(male_data[i].Year).getFullYear(), "Female": female_data[i]["Russia"], "Male": male_data[i]["Russia"]};
                uae_data[i] = {"Year": new Date(male_data[i].Year).getFullYear(), "Female": female_data[i]["United Arab Emirates"], "Male": male_data[i]["United Arab Emirates"]};
            }



            x = d3.scaleTime()
                .domain([new Date(1990), new Date(2023)])
                .range([ 0, width]);

            svg.append("g").attr("transform", "translate(0," + height + ")").call(d3.axisBottom(x).tickFormat(d3.format("d")));
        
            y = d3.scaleLinear()
                .domain([0, 100])
                .range([ height, 0]);
            
            svg.append("g").call(d3.axisLeft(y))

            //Legend
            svg.append("circle").attr("cx",850).attr("cy",100).attr("r", 6).style("fill", "rgb(254,6,147)")
            svg.append("text").attr("x",870).attr("y",105).text(function(d, i) { return "Female";})
            svg.append("circle").attr("cx",850).attr("cy",150).attr("r", 6).style("fill", "rgb(21,140,140)")
            svg.append("text").attr("x",870).attr("y",155).text(function(d, i) { return "Male";})
                
            //Initialize Default
            drawLolliPopChart('United States');
        });
    
});


//Listen For Changes
if(countrySelector){
    countrySelector.addEventListener('change', (event) => {
        drawLolliPopChart(countrySelector.value);
    });
} else {
    console.error("Failed to attach to Country Selector");
}

// Use this function to draw the lollipop chart.
function drawLolliPopChart(selectedCountry) {
    if(selectedCountry == "United States" || selectedCountry == "China" || selectedCountry == "Germany" || selectedCountry == "Russia" || selectedCountry == "United Arab Emirates"){
        switch(selectedCountry){
            case "United States":
                svg.selectAll("myline").remove();
                svg.selectAll("myline")
                .data(us_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year) + 20; })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year) + 20; })
                    .attr("y2", function(d) { return y(d.Female * 100); })
                    .attr("stroke", "rgb(254,6,147)")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });

                svg.selectAll("myline")
                .data(us_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year); })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year); })
                    .attr("y2", function(d) { return y(d.Male * 100); })
                    .attr("stroke", "rgb(21,140,140)")
                    .attr("padding", "2px")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });
                break;
            case "China":
                svg.selectAll("myline").remove();
                svg.selectAll("myline")
                .data(china_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year) + 20; })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year) + 20; })
                    .attr("y2", function(d) { return y(d.Female * 100); })
                    .attr("stroke", "rgb(254,6,147)")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });

                svg.selectAll("myline")
                .data(china_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year); })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year); })
                    .attr("y2", function(d) { return y(d.Male * 100); })
                    .attr("stroke", "rgb(21,140,140)")
                    .attr("padding", "2px")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });
                break;
            case "Germany":
                svg.selectAll("myline").remove();
                svg.selectAll("myline")
                .data(germany_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year) + 20; })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year) + 20; })
                    .attr("y2", function(d) { return y(d.Female * 100); })
                    .attr("stroke", "rgb(254,6,147)")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });

                svg.selectAll("myline")
                .data(germany_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year); })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year); })
                    .attr("y2", function(d) { return y(d.Male * 100); })
                    .attr("stroke", "rgb(21,140,140)")
                    .attr("padding", "2px")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });
                break;
            case "Russia":
                svg.selectAll("myline").remove();
                svg.selectAll("myline")
                .data(russia_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year) + 20; })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year) + 20; })
                    .attr("y2", function(d) { return y(d.Female * 100); })
                    .attr("stroke", "rgb(254,6,147)")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });

                svg.selectAll("myline")
                .data(russia_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year); })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year); })
                    .attr("y2", function(d) { return y(d.Male * 100); })
                    .attr("stroke", "rgb(21,140,140)")
                    .attr("padding", "2px")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });
                break;
            case "United Arab Emirates":
                svg.selectAll("myline").remove();
                svg.selectAll("myline")
                .data(uae_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year) + 20; })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year) + 20; })
                    .attr("y2", function(d) { return y(d.Female * 100); })
                    .attr("stroke", "rgb(254,6,147)")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });

                svg.selectAll("myline")
                .data(uae_data)
                .enter()
                .append("line")
                    .attr("x1", function(d) { return x(d.Year); })
                    .attr("y1", height)
                    .attr("x2", function(d) { return x(d.Year); })
                    .attr("y2", function(d) { return y(d.Male * 100); })
                    .attr("stroke", "rgb(21,140,140)")
                    .attr("padding", "2px")
                    .attr("stroke-width", "2px")
                    .attr("height", function(d) { return y(d.Female * 10); });
                break;
        }
    } else {
        console.error("Invalid Country Selection");
    }
}